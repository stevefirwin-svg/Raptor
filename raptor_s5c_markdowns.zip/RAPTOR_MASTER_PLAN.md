# Raptor — Master Priority Plan
*Last updated: 2026-06-12 (session 5 — position-level data audit + OU hold target + full markdown refresh)*
*Supersedes all prior versions. This is the single source of truth.*

---

## The Standard

Every number must be derivable from a formula, empirical data, or an optimization.
If "why that number?" cannot be answered, the number is wrong.

**Data integrity corollary:** Real data or skip. Never fabricate a fallback value that looks real.

**Audit integrity corollary (Rule 11):** A fix is only DONE when grep/test output is pasted
in the same session confirming it. Documented-but-unverified fixes are NOT done.

**Independence corollary:** Multiple trim events from one position entry are NOT independent
observations. All gating, IC, and DSR calculations use `position_outcomes.json` (one record
per position entry), never raw `outcome_log.json` directly.

---

## Current System State (verified 2026-06-12)

| Component | Status |
|-----------|--------|
| submit_order on AlpacaDataFeed | ✅ FIXED 2026-06-05, AST-verified every session |
| Crash visibility (3 entry points) | ✅ LIVE 2026-06-10 |
| Deterministic entry gate | ✅ LIVE 2026-06-10 — math governs, LLM advises |
| Gmail credentials | ✅ FIXED 2026-06-10 — env var, rotated password |
| Leveraged/inverse ETP exclusion | ✅ LIVE 2026-06-10 (variance drain, Cheng & Madhavan 2009) |
| Implementation shortfall tracker | ✅ LIVE 2026-06-10 (slippage_log.json, Perold 1988) |
| Cross-sectional sector neutralization | ✅ LIVE 2026-06-10 (Grinold & Kahn 2000) |
| Deflated Sharpe Ratio | ✅ LIVE 2026-06-10 (Bailey & López de Prado 2014) |
| OU-derived hold target | ✅ LIVE 2026-06-11 (Leung & Zhang 2019) — replaces 16+14*atr_pctile |
| exit_regime in outcome records | ✅ LIVE 2026-06-11 |
| Survivorship bias warning in backtest | ✅ LIVE 2026-06-11 |
| Regime drift metric | ✅ LIVE 2026-06-11 |
| position_outcomes.json | ✅ LIVE 2026-06-12 — deduplicated position-level records |
| DSR corrected to position-level | ✅ FIXED 2026-06-12 — true DSR 59.8% (was falsely 99.9%) |
| P0-1 outcome sidecar | ✅ LIVE 2026-05-29 |
| P0-8 regime unification | ✅ LIVE 2026-05-29 |
| DFA-1 Hurst | ✅ LIVE 2026-05-29 |
| Spearman IC + WLS + decay | ✅ LIVE |
| Bootstrap Kelly — SHADOW mode | ✅ LIVE (43/100 trades) |
| Dual-book engine (MOMENTUM live, MR suspended) | ✅ LIVE |
| Bat file log isolation (raptor_auto_start.log) | ✅ FIXED 2026-06-10 |

---

## Data State (verified 2026-06-12)

| Metric | Value | Notes |
|--------|-------|-------|
| outcome_log.json total records | 135 | Raw, includes all trim events |
| IC-valid terminal exits (raw) | 76 | Multiple trim events from same position NOT independent |
| **Independent positions (position_outcomes.json)** | **27** | **Use this for all gating** |
| Clean positions (no quality flags) | 22 | Excludes leveraged ETPs; no_entry_decision flagged but usable |
| True DSR | 59.8% — WEAK | n=24, SR=1.42, SR*=1.22 |
| Win rate (position-level) | 59.1% | 13W/9L on clean positions |
| Mean position PnL | 5.47% | Was falsely 7.19% from multi-trim inflation |
| Kelly mode | SHADOW (43/100) | Not yet active |
| Factor IC | PROVISIONAL | Built on proxy history, not clean position outcomes |
| slippage_log.json | Accumulating | Data flows from 2026-06-10 onwards |

**WARNING: outcome_log.json multi-trim inflation**
76 "trades" in outcome_log.json are actually 27 independent positions.
PLTD: 9 records from 1 entry. AMD: 4 records. 49/76 records are non-independent.
ALL IC, DSR, and gate calculations MUST use position_outcomes.json.

---

## Gates (updated 2026-06-12)

| Gate | Metric | Current | Target | Unlocks |
|------|--------|---------|--------|---------|
| **DATA-40** | Independent positions in position_outcomes.json | 27 | 40 | MATH-1, GAP-B first pass |
| **DATA-60** | Independent positions | 27 | 60 | MATH-5, ARCH-1, Kelly shadow→active |
| **DATA-100** | Independent positions | 27 | 100 | Kelly ACTIVE mode |
| **DATA-200** | Position-days | ~430 | 200+ | ARCH-3 full covariance Kelly |

At current pace (~7 positions/week): DATA-40 in ~2 weeks, DATA-60 in ~5 weeks.

---

## Session 4 Fixes (all Rule 11 verified, commit 0fc61f0)

| ID | Fix |
|----|-----|
| S4-1 | Crash visibility: main.py, exit_monitor.py, hold_monitor.py — logger.exception to log file on uncaught error |
| S4-2 | Deterministic entry gate: _eval_entry_rules() — 6 boolean rules in Python, LLM advisory only |
| S4-3 | Gmail app password removed from daily_recap.py + morning_scanner_email.py → EMAIL_APP_PASSWORD env var |
| S4-4 | 9 bat files: auto_start.log → raptor_auto_start.log |
| S4-5 | universe_builder: leveraged/inverse ETP exclusion via name pattern (Cheng & Madhavan 2009) |

## Session 4b–4d Fixes (all Rule 11 verified)

| ID | Commit | Fix |
|----|--------|-----|
| S4b | be8f37b | slippage_tracker.py — IS recording on every BUY/SELL fill, backfill via outcome_tracker, section in recap email |
| S4c | 3857259 | signals.py sector neutralization — factor z-scores demeaned per sector before IVW (Grinold & Kahn 2000) |
| S4d | 3b647bd | dsr.py — Deflated Sharpe Ratio (Bailey & López de Prado 2014), wired into AfterClose + recap email |

## Session 5 Fixes (commit 57c08d7 + 0a30513)

| ID | Fix |
|----|-----|
| S5-1 | OU hold target: ln(2)/θ via AR(1) OLS on log prices replaces 16+14*atr_pctile (Leung & Zhang 2019) |
| S5-2 | exit_regime field in build_outcome_record — enables regime drift metric |
| S5-3 | Survivorship bias warning in backtest.py metrics dict (Brown, Goetzmann & Ross 1995; Shumway 1997) |
| S5-4 | _get_regime_drift() in daily_recap — regime transition matrix entry→exit |
| S5-5 | position_outcomes.json — 27 independent positions aggregated from 76 trim events |
| S5-6 | dsr.py updated to use position_outcomes.json — true DSR 59.8% (was falsely 99.9%) |

---

## Open Priority Queue

### No data gate — can build any session

| # | Item | File | Notes |
|---|------|------|-------|
| 1 | Agent-vs-math disagreement rate in daily_recap | daily_recap.py | Data flowing from S4-2 (2026-06-10); needs 1 week of records |
| 2 | ARCH-2: HMM macro regime for Raptor | macro_context.py | Hamilton (1989) via hmmlearn; probability vector output, no discrete labels. Ares already has it. |
| 3 | ARCH-5: Point-in-time universe | universe_builder.py | Requires external data source (Quandl/Sharadar). Survivorship warning already in backtest. |
| 4 | margin_guard.py WARN_THRESHOLD derivation | margin_guard.py | TODO:DERIVE — needs equity curve data. Guard is fully wired and correct; threshold needs calibration. |
| 5 | P2-8: ATR expansion binary → continuous | hold_monitor.py | Layer returns 0.0 for 0.80–1.20 range — loses information in normal volatility |
| 6 | P2-9: Stop distance layer zero signal | hold_monitor.py | Zero stop distance should be strong negative, not neutral |
| 7 | P1-15: Sentiment dead path | signals.py | sentiment_score always 0.0 — remove or fix the pipeline |
| 8 | raptor_session4_fixes.zip in repo | repo root | `del raptor_session4_fixes.zip` + `git rm` if present |

### DATA-40 gate (≥40 independent positions in position_outcomes.json)

| # | Item | Reference |
|---|------|-----------|
| 1 | GAP-B: Trail tier calibration first pass | Thorp 2006; backtest drawdown analysis |
| 2 | MATH-1: Regime-conditional IC buckets | ic_by_regime split in signals.py AdaptiveWeights._fit() |

### DATA-60 gate (≥60 independent positions)

| # | Item | Reference |
|---|------|-----------|
| 1 | MATH-5: Reduce n_prior 50→20 in kelly_engine.py | Bayesian Kelly prior reduction |
| 2 | ARCH-1: IC layer weights in hold_monitor | Spearman IC per layer vs realized PnL |
| 3 | Kelly shadow → active mode | Config flag flip |
| 4 | Noise-band floor derivation from gap_atr log data | EVT/GPD via scipy.stats.genpareto |
| 5 | Purged walk-forward IC validation | López de Prado 2018 ch.7 — purge + embargo |

### DATA-200 gate

| # | Item |
|---|------|
| 1 | ARCH-3: Full covariance Kelly |
| 2 | ARCH-4: LightGBM non-linear factor model (500+ clean trades) |

---

## Arbitrary Constants — Must Derive (updated)

| Location | Constant | How to derive | Gate |
|----------|---------|---------------|------|
| signals.py | Kelly SNR normalizer /3.0 | Bootstrap Kelly percentile distribution | DATA-40 |
| signals.py | Kelly clip 0.02/0.12 | EVT tail on closed position returns | DATA-40 |
| signals.py | Regime blend sigma 0.25 | Historical regime transition frequency | None — derive from macro_context history |
| signals.py | OU hold_target min=3, max=30 | Regress realized hold_days vs theta estimate | DATA-40 |
| hold_monitor.py | LAYER_WEIGHTS (hand-picked) | Spearman IC per layer vs PnL | DATA-60 (ARCH-1) |
| hold_monitor.py | TIER_STRONG=0.20, TIER_STABLE=-0.15 | Health score vs forward return distribution | DATA-40 |
| exit_monitor.py | Trail modifier 0.3/1.3/0.75 | Backtest trail width sensitivity | DATA-40 (GAP-B) |
| config.py | initial_stop_atr_mult 3.0 | EVT-derived — gate: DATA-60 | DATA-60 |
| config.py | max_portfolio_drawdown 0.12 | EVT tail on portfolio return distribution | DATA-60 |
| macro_context.py | Vote thresholds 3/0/-2 | Replace with HMM probability vector (ARCH-2) | None |
| dsr.py | N_TRIALS_DEFAULT = 10 | Count of strategy-altering commits — update each session | Rolling |

---

## P1 Status Table (updated 2026-06-12)

| ID | Description | Status |
|----|-------------|--------|
| P1-1 | Kalman macro classifier | NOT BUILT — replaced by Gaussian regime blend in signals.py |
| P1-2 | Vol-regime hard stop | ✅ CONFIRMED |
| P1-3 | OU trailing stop | ✅ CONFIRMED |
| P1-4 | Bayesian Kelly | ✅ CONFIRMED — bootstrap live, SHADOW mode |
| P1-5 | OU hold target | ✅ FIXED 2026-06-11 — ln(2)/θ AR(1) OLS (Leung & Zhang 2019) |
| P1-6 | IC layer weights hold monitor | GATED — DATA-60 (currently 27 positions) |
| P1-7 | Continuous trim | ✅ CONFIRMED |
| P1-8 | Regime-relative thesis threshold | ✅ CONFIRMED |
| P1-9 | Watchdog intraday | NOT BUILT — fetches 5 daily bars, not intraday. Rebuild or remove bat. |
| P1-10 | Composite velocity gate | ✅ CONFIRMED |
| P1-11 | Re-entry cooldown | ✅ CONFIRMED |
| P1-12 | Portfolio heat partial trim | ✅ CONFIRMED (25% proportional) |
| P1-13 | Multi-MA breadth (50/150/200) | ✅ CONFIRMED |
| P1-14 | Universe sensitivity sweep | FUTURE (ARCH-5) |
| P1-15 | Sentiment dead path | OPEN — sentiment_score always 0.0 |
| P1-16 | Afternoon rescore | PARTIAL — exit_monitor GAP9 rescore live |
| P1-17 | Conviction gradient sizing | ✅ CONFIRMED via book_conviction percentile |

---

## Known Issues — Open

| Issue | Impact | Priority |
|-------|--------|----------|
| Trail multiplier tiers (2.5/2.0/2.5×) — TODO:DERIVE | Stops may be too tight/loose on winners | GAP-B at DATA-40 |
| macro_context.py vote-count thresholds — no statistical basis | Regime misclassification risk | ARCH-2: replace with HMM |
| position_outcomes.json built manually — not auto-updated after close | New positions won't appear until Claude rebuilds it | Add to Start_AfterClose.bat |
| raptor_s5b_positions.zip in repo root | Unnecessary weight | `git rm raptor_s5b_positions.zip` |
| UnicodeEncodeError on → character in log output | Cosmetic logging error | Low priority |

---

## Completed (all sessions, chronological)

All pre-session-4 completions archived. For full history see git log.
Key pre-S4 completions: CRIT-0 through CRIT-9, MATH-2/3/4, H-1 through H-8,
P0-1, P0-8, submit_order fix, trail tier interim fix, double-trim guard,
log tracking enabled, DFA-1 Hurst, soft z-score shrinkage, Ledoit-Wolf SNR.
